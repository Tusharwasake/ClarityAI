export {};
//# sourceMappingURL=popup.d.ts.map