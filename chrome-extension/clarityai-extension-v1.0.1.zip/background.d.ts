/**
 * Background Script - Service Worker
 * Handles extension lifecycle and background tasks
 */
//# sourceMappingURL=background.d.ts.map