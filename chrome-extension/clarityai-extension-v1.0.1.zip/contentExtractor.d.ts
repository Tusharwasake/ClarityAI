import { ContentExtraction } from "./types";
/**
 * Main content extraction function
 */
export declare function extractContent(): ContentExtraction;
/**
 * Check if page has significant content
 */
export declare function hasSignificantContent(): boolean;
/**
 * Detect if this is likely a long-form article
 */
export declare function isLongFormContent(): boolean;
/**
 * Check if page should be processed
 */
export declare function shouldProcessPage(): boolean;
//# sourceMappingURL=contentExtractor.d.ts.map