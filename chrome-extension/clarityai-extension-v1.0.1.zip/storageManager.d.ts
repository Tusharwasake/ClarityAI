import { Summary, ExtensionSettings } from "./types";
/**
 * Local Storage & Quick Access
 * Manages summaries and settings in Chrome storage
 */
export declare class StorageManager {
    private static readonly MAX_SUMMARIES;
    private static readonly SUMMARIES_KEY;
    private static readonly SETTINGS_KEY;
    /**
     * Get default settings
     */
    static getDefaultSettings(): ExtensionSettings;
    /**
     * Save a summary to local storage
     */
    static saveSummary(summary: Summary): Promise<void>;
    /**
     * Get all saved summaries
     */
    static getSummaries(): Promise<Summary[]>;
    /**
     * Delete a specific summary
     */
    static deleteSummary(summaryId: string): Promise<void>;
    /**
     * Clear all summaries
     */
    static clearSummaries(): Promise<void>;
    /**
     * Get extension settings
     */
    static getSettings(): Promise<ExtensionSettings>;
    /**
     * Save extension settings
     */
    static saveSettings(settings: ExtensionSettings): Promise<void>;
    /**
     * Update extension settings (partial update)
     */
    static updateSettings(updates: Partial<ExtensionSettings>): Promise<void>;
    /**
     * Check if the extension is enabled for a specific site
     */
    static isEnabledForSite(url: string): Promise<boolean>;
    /**
     * Toggle extension for a specific site
     */
    static toggleSite(url: string): Promise<void>;
    /**
     * Enable extension for a specific site
     */
    static enableSite(url: string): Promise<void>;
    /**
     * Disable extension for a specific site
     */
    static disableSite(url: string): Promise<void>;
    /**
     * Export summary as text
     */
    static exportSummaryAsText(summary: Summary): string;
    /**
     * Export summary as markdown
     */
    static exportSummaryAsMarkdown(summary: Summary): string;
    /**
     * Generate unique ID for summary
     */
    static generateSummaryId(): string;
}
//# sourceMappingURL=storageManager.d.ts.map