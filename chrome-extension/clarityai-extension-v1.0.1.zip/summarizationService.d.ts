import { SummaryRequest, SummaryResponse } from "./types";
/**
 * Generate summary from content
 */
export declare function summarize(request: SummaryRequest): Promise<SummaryResponse>;
/**
 * Generate fallback summary (client-side basic summarization)
 * Used when API is unavailable
 */
export declare function generateFallbackSummary(content: string, title: string): string[];
/**
 * Check if the summarization service is available
 */
export declare function isServiceAvailable(): Promise<boolean>;
//# sourceMappingURL=summarizationService.d.ts.map